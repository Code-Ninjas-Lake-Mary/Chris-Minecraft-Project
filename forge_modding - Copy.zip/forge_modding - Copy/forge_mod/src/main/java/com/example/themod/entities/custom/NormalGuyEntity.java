package com.example.themod.entities.custom;

import javax.annotation.Nullable;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.Level;

public class NormalGuyEntity extends Villager{

	public NormalGuyEntity(EntityType<? extends Villager> pEntityType, Level pLevel) {
		super(pEntityType, pLevel);
		
	}
@Override
protected void registerGoals() {
	this.goalSelector.addGoal(0, new FloatGoal(this));
}
	
	
public static AttributeSupplier.Builder createAttribute() {
	return Villager.createLivingAttributes()
			.add(Attributes.JUMP_STRENGTH, 1D)
			.add(Attributes.KNOCKBACK_RESISTANCE, 6D)
			.add(Attributes.ATTACK_DAMAGE, 3D)
			.add(Attributes.MOVEMENT_SPEED, 1.3D)
			.add(Attributes.ARMOR, 20D)
			.add(Attributes.FOLLOW_RANGE, 24D)
			.add(Attributes.MAX_HEALTH, 50D)
			.add(Attributes.ARMOR_TOUGHNESS, 8D)
			.add(Attributes.ATTACK_KNOCKBACK, 2D)
			.add(Attributes.LUCK, 20D);
}
@Nullable
@Override
protected SoundEvent getAmbientSound() {
	return SoundEvents.VILLAGER_AMBIENT;
}

@Nullable
@Override
protected SoundEvent getHurtSound(DamageSource pDamageSource) {
	return SoundEvents.VILLAGER_HURT;
}

@Nullable
@Override
protected SoundEvent getDeathSound() {
	return SoundEvents.VILLAGER_DEATH;
}


}
