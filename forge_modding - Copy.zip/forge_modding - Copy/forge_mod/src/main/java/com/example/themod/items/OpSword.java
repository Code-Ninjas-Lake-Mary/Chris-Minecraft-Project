package com.example.themod.items;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;

public class OpSword extends SwordItem {
	public OpSword() {
		super(Tiers.DIAMOND, 99999, 99999, new Item.Properties());
	}
}
