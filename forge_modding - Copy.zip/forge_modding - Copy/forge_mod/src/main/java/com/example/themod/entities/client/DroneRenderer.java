package com.example.themod.entities.client;

import com.example.themod.themod;
import com.example.themod.entities.custom.DroneEntity;
import com.example.themod.entities.custom.NormalGuyEntity;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class DroneRenderer extends MobRenderer<DroneEntity, Drone<DroneEntity>> {
	public DroneRenderer(EntityRendererProvider.Context pContext) {
	super(pContext, new Drone<>(pContext.bakeLayer(ModModelLayers.DRONE_LAYER)), 2f);
	shadowRadius = 0.4F;
}

@Override
public ResourceLocation getTextureLocation(DroneEntity p_115812_) {
	// TODO Auto-generated method stub
	return new ResourceLocation(themod.MOD_ID, "textures/entity/drone.png");
}

@Override
public void render(DroneEntity pEntity, float pEntityYaw, float pPartialTicks, PoseStack pMatrixStack,
		MultiBufferSource pBuffer, int pPackedLight) {
				if(pEntity.isBaby()) {
	pMatrixStack.scale(0.2f, 0.5f, 0.2f);
		}
				
	super.render(pEntity, pEntityYaw, pPartialTicks, pMatrixStack, pBuffer, pPackedLight);
	}
}