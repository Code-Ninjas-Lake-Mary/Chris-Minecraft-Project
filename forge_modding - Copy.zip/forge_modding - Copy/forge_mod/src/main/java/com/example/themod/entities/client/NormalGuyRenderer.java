package com.example.themod.entities.client;

import com.example.themod.themod;
import com.example.themod.entities.custom.NormalGuyEntity;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class NormalGuyRenderer extends MobRenderer<NormalGuyEntity, NormalGuy<NormalGuyEntity>> {
	
	public NormalGuyRenderer(EntityRendererProvider.Context pContext) {
		super(pContext, new NormalGuy<>(pContext.bakeLayer(ModModelLayers.NORMALGUY_LAYER)), 2f);
		shadowRadius = 0.7F;
	}

	@Override
	public ResourceLocation getTextureLocation(NormalGuyEntity p_115812_) {
		// TODO Auto-generated method stub
		return new ResourceLocation(themod.MOD_ID, "textures/entity/normal_dude_texture.png");
	}
	
	@Override
	public void render(NormalGuyEntity pEntity, float pEntityYaw, float pPartialTicks, PoseStack pMatrixStack,
			MultiBufferSource pBuffer, int pPackedLight) {
					if(pEntity.isBaby()) {
		pMatrixStack.scale(0.07f, 0.08f, 0.07f);
			}
					
		super.render(pEntity, pEntityYaw, pPartialTicks, pMatrixStack, pBuffer, pPackedLight);
	}
}