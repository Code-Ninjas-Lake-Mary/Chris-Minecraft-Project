package com.example.themod.entities.custom;

import javax.annotation.Nullable;

import com.example.themod.entities.ModEntities;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

public class DroneEntity extends Monster{

	public DroneEntity(EntityType<? extends Monster> pEntityType, Level pLevel) {
		super(pEntityType, pLevel);
			
	}
	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(1, new FloatGoal(this));
	}
		
		
public static AttributeSupplier.Builder createAttributes() {
	return Monster.createLivingAttributes()
				.add(Attributes.JUMP_STRENGTH, 1D)
				.add(Attributes.KNOCKBACK_RESISTANCE, 0.3D)
				.add(Attributes.ATTACK_DAMAGE, 12D)
				.add(Attributes.MOVEMENT_SPEED, 1.8D)
				.add(Attributes.FOLLOW_RANGE, 40D)
				.add(Attributes.ARMOR, 7D)
				.add(Attributes.MAX_HEALTH, 14D)
				.add(Attributes.ARMOR_TOUGHNESS, 3D)
				.add(Attributes.ATTACK_KNOCKBACK, 2D);
}

@Nullable
@Override
protected SoundEvent getAmbientSound() {
	return SoundEvents.ANVIL_HIT;
}

@Nullable
@Override
protected SoundEvent getHurtSound(DamageSource pDamageSource) {
	return SoundEvents.ANVIL_BREAK;
}

@Nullable
@Override
protected SoundEvent getDeathSound() {
	return SoundEvents.ANVIL_LAND;
}

}