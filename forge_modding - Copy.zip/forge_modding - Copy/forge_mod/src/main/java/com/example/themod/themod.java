package com.example.themod;


import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.example.themod.entities.ModEntities;
import com.example.themod.entities.client.DroneRenderer;
import com.example.themod.entities.client.NormalGuyRenderer;
import com.example.themod.init.ItemInit;

import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.core.registries.Registries;


@Mod("themod")
@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class themod {
	
public static final Logger LOGGER = LogManager.getLogger();
public static final String MOD_ID = "themod";
public static int consumed = 0;
public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);	


public themod() {
	


final IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

ModEntities.register(modEventBus);

	modEventBus.addListener(this::setup);
	ItemInit.ITEMS.register(modEventBus);
	
	MinecraftForge.EVENT_BUS.register(this);
	
	final IEventBus forgeEventBus = MinecraftForge.EVENT_BUS;
	forgeEventBus.register(new MyForgeEventHandler());
	

}

public void setup(final FMLCommonSetupEvent event) {
    event.enqueueWork(() -> {
    });
}

public class MyForgeEventHandler {
	@SubscribeEvent
	public void eatItem(LivingEntityUseItemEvent.Finish event) {
		consumed++;
		LivingEntity player = event.getEntity();
		
		if(consumed >= 10) {
			if(!player.hasEffect(MobEffects.REGENERATION))
				player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 4000));
		}
	}
}

@Mod.EventBusSubscriber(modid = themod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
	@SubscribeEvent
	public static void onClientSetup(FMLClientSetupEvent event) {
		EntityRenderers.register(ModEntities.NORMALGUYENTITY.get(), NormalGuyRenderer::new);
		EntityRenderers.register(ModEntities.DRONEENTITY.get(), DroneRenderer::new);
		}
	}
}
