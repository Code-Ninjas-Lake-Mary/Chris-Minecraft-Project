package com.example.themod.entities;

import com.example.themod.themod;
import com.example.themod.entities.custom.DroneEntity;
import com.example.themod.entities.custom.NormalGuyEntity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
	public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = 
			DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, themod.MOD_ID);
	
	public static final RegistryObject<EntityType<NormalGuyEntity>> NORMALGUYENTITY =
			ENTITY_TYPES.register("normalguyentity", () -> EntityType.Builder.of(NormalGuyEntity::new, MobCategory.CREATURE)
					.sized(1f, 2f).build("normalguyentity"));
	
	public static final RegistryObject<EntityType<DroneEntity>> DRONEENTITY =
			ENTITY_TYPES.register("droneentity", () -> EntityType.Builder.of(DroneEntity::new, MobCategory.CREATURE)
					.sized(0.2f, 1.1f).build("droneentity"));
	
	public static void register(IEventBus eventBus) {
		ENTITY_TYPES.register(eventBus);
		
	}
}