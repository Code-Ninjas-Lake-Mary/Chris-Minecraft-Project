package com.example.themod.items;



import net.minecraft.world.item.Item;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;

public class CustomSword extends SwordItem {
	public CustomSword() {
		super(Tiers.DIAMOND, 15, 5, new Item.Properties());
	}
}
