package com.example.themod.entities.client;
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

public class NormalGuy<T extends Entity> extends HierarchicalModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("modid", "normalguy"), "main");
	private final ModelPart normalguy;
	private final ModelPart legs;
	private final ModelPart legs2;
	private final ModelPart arms;
	private final ModelPart arms2;
	private final ModelPart head;

	public NormalGuy(ModelPart root) {
		this.normalguy = root.getChild("normalguy");
		this.head = normalguy.getChild("head");
		this.legs = normalguy.getChild("legs");
		this.arms = normalguy.getChild("arms");
		this.legs2 = normalguy.getChild("legs2");
		this.arms2 = normalguy.getChild("arms2");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition normalguy = partdefinition.addOrReplaceChild("normalguy", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

		PartDefinition legs = normalguy.addOrReplaceChild("legs", CubeListBuilder.create().texOffs(16, 44).addBox(-2.0F, -0.65F, -2.0F, 4.0F, 16.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(4.5F, -14.35F, -0.15F));

		PartDefinition body = normalguy.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offset(-4.55F, -18.6F, -0.15F));

		PartDefinition cube_r1 = body.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(2, 2).addBox(-16.4F, -12.25F, -3.0F, 20.0F, 16.0F, 6.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.5708F));

		PartDefinition arms = normalguy.addOrReplaceChild("arms", CubeListBuilder.create().texOffs(40, 24).addBox(-2.0F, -0.95F, -2.0F, 4.0F, 17.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(9.7F, -33.85F, -0.15F));

		PartDefinition head = normalguy.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 24).addBox(-5.0F, -5.0F, -5.0F, 10.0F, 10.0F, 10.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, -41.0F, 0.0F));

		PartDefinition legs2 = normalguy.addOrReplaceChild("legs2", CubeListBuilder.create().texOffs(32, 45).addBox(-2.0F, -0.65F, -2.0F, 4.0F, 16.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(-4.55F, -14.35F, -0.15F));

		PartDefinition arms2 = normalguy.addOrReplaceChild("arms2", CubeListBuilder.create().texOffs(0, 44).addBox(-2.0F, 0.05F, -2.0F, 4.0F, 17.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(-10.35F, -34.85F, -0.15F));

		PartDefinition neck = normalguy.addOrReplaceChild("neck", CubeListBuilder.create().texOffs(54, 0).addBox(-4.0F, -36.55F, -2.35F, 8.0F, 2.0F, 5.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		normalguy.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	@Override
	public ModelPart root() {
		// TODO Auto-generated method stub
		return normalguy;
	}
}