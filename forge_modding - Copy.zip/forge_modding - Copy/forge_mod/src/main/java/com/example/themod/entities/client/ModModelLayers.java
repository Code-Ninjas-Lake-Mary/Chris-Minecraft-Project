package com.example.themod.entities.client;

import com.example.themod.themod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;

public class ModModelLayers {
	public static final ModelLayerLocation NORMALGUY_LAYER = new ModelLayerLocation(
			new ResourceLocation(themod.MOD_ID, "normalguy_layer"), "main");
	public static final ModelLayerLocation DRONE_LAYER = new ModelLayerLocation(
			new ResourceLocation(themod.MOD_ID, "drone_layer"), "main");
}