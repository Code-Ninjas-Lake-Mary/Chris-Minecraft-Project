package com.example.themod.event;

import com.example.themod.themod;
import com.example.themod.entities.ModEntities;
import com.example.themod.entities.custom.DroneEntity;
import com.example.themod.entities.custom.NormalGuyEntity;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = themod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ModEventBusEvents {
	@SubscribeEvent
	public static void registerAttirbutes(EntityAttributeCreationEvent event) {
		event.put(ModEntities.NORMALGUYENTITY.get(), NormalGuyEntity.createAttributes().build());
		event.put(ModEntities.DRONEENTITY.get(), DroneEntity.createAttributes().build());
	}
}