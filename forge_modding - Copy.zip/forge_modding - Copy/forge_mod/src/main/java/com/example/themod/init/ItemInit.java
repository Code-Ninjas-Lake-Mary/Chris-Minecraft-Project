package com.example.themod.init;

import java.util.function.Supplier;

import org.jetbrains.annotations.NotNull;

import com.example.themod.themod;
import com.example.themod.block.custom.ModPortalBlock;
import com.example.themod.entities.ModEntities;
import com.example.themod.items.CustomSword;
import com.example.themod.items.FuelItem;
import com.example.themod.items.OpSword;
import com.example.themod.items.TeleportStaff;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.client.model.generators.BlockStateProvider;
import net.minecraftforge.client.model.generators.ConfiguredModel;
import net.minecraftforge.client.model.generators.BlockModelProvider;
import net.minecraftforge.client.model.generators.ModelProvider;
import net.minecraft.client.model.Model;

public class ItemInit {
	
	 public static final DeferredRegister<Block> BLOCKS =
	            DeferredRegister.create(ForgeRegistries.BLOCKS, themod.MOD_ID);
	
	public static final DeferredRegister<Item> ITEMS = 
			DeferredRegister.create(ForgeRegistries.ITEMS, themod.MOD_ID);
	
	public static final RegistryObject<Item> ROLL = ITEMS.register("roll",
			()-> new Item((new Item.Properties()
					.food(new FoodProperties.Builder().nutrition(4).saturationMod(2).alwaysEat().build()))));

	public static final RegistryObject<Item> FUEL = ITEMS.register("fuel",
			()-> new FuelItem((new Item.Properties()), 1800));
	
	public static final RegistryObject<Item> TELEPORT_STAFF = ITEMS.register("teleport_staff",
			()-> new TeleportStaff(new Item.Properties()));
	
	public static final RegistryObject<Item> DRONE_SPAWN_EGG = ITEMS.register("drone_spawn_egg",
			()-> new ForgeSpawnEggItem(ModEntities.DRONEENTITY, 0x808080, 0xFF0000, new Item.Properties()));
	
	public static final RegistryObject<Item> DUDE_SPAWN_EGG = ITEMS.register("dude_spawn_egg",
			()-> new ForgeSpawnEggItem(ModEntities.NORMALGUYENTITY, 0xD2B48C, 0xFF0000, new Item.Properties()));
	
	public static final RegistryObject<Item> CUSTOMSWORD = ITEMS.register("fire_sword",
			()-> new CustomSword());
	
	public static final RegistryObject<Item> OPSWORD = ITEMS.register("op_sword",
			()-> new OpSword());
	
	public static final RegistryObject<Block> MOD_PORTAL = registerBlock("mod_portal",
			()-> new ModPortalBlock(BlockBehaviour.Properties.copy(Blocks.STONE).noLootTable().noOcclusion().noCollission()));
	
	public static final DeferredRegister<CreativeModeTab> MODTAB = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, themod.MOD_ID);
	
	public static final RegistryObject<CreativeModeTab> EXAMPLE_TAB = MODTAB.register("tab", 
			() -> CreativeModeTab.builder()
			  .title(Component.translatable("Suger & Spice.tab"))
			  .icon(ROLL.get()::getDefaultInstance)
			  .displayItems((params, output) -> {
			    output.accept(ROLL.get());
			    output.accept(DRONE_SPAWN_EGG.get());
			    output.accept(FUEL.get());
			    output.accept(TELEPORT_STAFF.get());
			    output.accept(DUDE_SPAWN_EGG.get());
			  })
			  .build()
			);

	private static <T extends Block> RegistryObject<T> registerBlock(String name, Supplier<T> block) {
		RegistryObject<T> toReturn = BLOCKS.register(name, block);
		registerBlockItem(name, toReturn);
		return toReturn;
	}

	private static <T extends Block> RegistryObject<Item> registerBlockItem(String name, RegistryObject<T> block) {
        return ItemInit.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }

    public static void register(IEventBus eventBus) {
        BLOCKS.register(eventBus);
		
    }
}
