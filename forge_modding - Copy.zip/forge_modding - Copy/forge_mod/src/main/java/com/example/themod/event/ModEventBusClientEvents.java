package com.example.themod.event;

import com.example.themod.themod;
import com.example.themod.entities.ModEntities;
import com.example.themod.entities.client.Drone;
import com.example.themod.entities.client.ModModelLayers;
import com.example.themod.entities.client.NormalGuy;
import com.example.themod.entities.custom.NormalGuyEntity;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = themod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ModEventBusClientEvents {
	@SubscribeEvent
	public static void registerLayer(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(ModModelLayers.NORMALGUY_LAYER, NormalGuy::createBodyLayer);
		event.registerLayerDefinition(ModModelLayers.DRONE_LAYER, Drone::createBodyLayer);
	}
}
